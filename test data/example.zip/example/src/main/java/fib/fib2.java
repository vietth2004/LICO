package fib;

public class fib2 {
    public int fib(int n) {
        if (n < 2) return n;

        int a = 0, b = 1;
        for (int i = 2; i <= n; i++) {
            int c = a + b;

            if (i == n) {          //  lỗi chỉ tại m lần lặp
                b = a;             // cập nhật sai ở vòng cuối
            } else {
                a = b;
                b = c;
            }
        }
        return b;
    }

}
