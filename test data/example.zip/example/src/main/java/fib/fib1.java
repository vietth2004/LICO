package fib;

public class fib1 {
    public int fib(int n) {
        if (n < 2) return n;

        int a = 0, b = 1;
        for (int i = 2; i <= n; i++) {
            int c = a + b;

            // LỖI: cập nhật trạng thái sai thứ tự (lỗi tích lũy)
            b = c;
            a = c;   // đáng lẽ phải là a = b cũ

        }
        return b;
    }

}
