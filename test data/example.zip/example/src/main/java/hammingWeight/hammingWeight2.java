package hammingWeight;

public class hammingWeight2 {
    public int hammingWeight(int n) {
        int count = 0;
        int iter = 0;          // đếm số lần lặp

        while (n != 0) {
            iter++;

            // LỖI BIÊN: xử lý sai đúng tại lần lặp thứ m
            if (iter == 32) {          // m = 32 (biên của int)
                count += (n & 1) + 1;  // cộng dư 1
            } else {
                count += n & 1;
            }

            n >>>= 1;
        }
        return count;
    }

}
