package hammingWeight;

public class hammingWeight4 {
    public int hammingWeight(int n) {
        int count = 0;
        int iter = 0;

        while (n != 0 || iter == 32) {   // lỗi: cho phép thêm 1 lần lặp
            count += n & 1;
            n >>>= 1;
            iter++;
        }

        return count;
    }

}
