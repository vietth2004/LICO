package hammingWeight;

public class hammingWeight3 {
    public int hammingWeight(int n) {
        int count = 0;
        int step = 0;

        while (n != 0) {
            // LỖI: bỏ qua cộng bit tại lần lặp m−1
            if (step != 30) {   // giả sử m = 31 bit có ý nghĩa
                count += n & 1;
            }

            n >>>= 1;
            step++;
        }

        return count;
    }

}
