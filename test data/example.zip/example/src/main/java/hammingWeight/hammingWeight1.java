package hammingWeight;

public class hammingWeight1 {
    public int hammingWeight(int n) {
        int count = 0;
        int iter = 0;   // đếm số vòng lặp

        while (n != 0) {
            iter++;

            if (iter > 1) {
                // LỖI: sau lần lặp đầu, cộng sai giá trị
                count += (n & 1) * 2;
            } else {
                count += n & 1;
            }

            n >>>= 1;
        }

        return count;
    }

}
