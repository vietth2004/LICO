package smallestDigit;

public class smallestDigit4 {
    public int smallestDigit(int n) {
        int min = 9;

        do {
            int d = n % 10;

            if (d < min) {
                min = d;
            }

            n /= 10;
        } while (n >= 0); // lỗi: cho phép vòng lặp chạy thêm 1 lần

        return min;
    }

}
