package smallestDigit;

public class smallestDigit {
    public int smallestDigit(int n) {
        int min = 9;
        while (n > 0) {
            int d = n % 10;
            if (d < min) min = d;
            n /= 10;
        }
        return min;
    }
}
