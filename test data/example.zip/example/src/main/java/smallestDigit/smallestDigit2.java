package smallestDigit;

public class smallestDigit2 {
    public int smallestDigit(int n) {
        int min = 9;

        while (n > 0) {
            int d = n % 10;

            // Lỗi chỉ xuất hiện ở lần lặp cuối (m)
            if (n < 10) {
                // xử lý sai ở lần lặp cuối
                if (d > min) {
                    min = d;   // đáng lẽ không cập nhật
                }
            } else {
                if (d < min) {
                    min = d;
                }
            }

            n /= 10;
        }

        return min;
    }

}
