public class Algorithm {

    public static int fibonacci(int n) {
        int a = 0, b = 1, c, i;
        if (n == 0)
            return a;
        for (i = 2; i <= n; i++) {
            c = a + b;
            a = b;
            b = c;
        }
        return b;
    }

    private static boolean leapYear(int year) {
        if (year % 4 == 0) {
            if (year % 100 == 0) {
                if (year % 400 == 0)
                    return true;
                else
                    return false;
            } else
                return true;
        } else
            return false;
    }

    public static int calDigits(char start, char end) {
        int sum = 0;
        for (char ch = start; ch <= end; ch++) {
            sum += 1;
        }
        return sum;
    }

    public static boolean isTriangle(int a, int b, int c) {
        if (a <= 0 || b <= 0 || c <= 0) {
            return false;
        } else if (a + b <= c || a + c <= b || b + c <= a)
            return false;
        else
            return true;
    }

    private static int findMax(int n1, int n2, int n3) {
        int maxN1N2;
        if (n1 > n2) {
            maxN1N2 = n1;
        } else {
            maxN1N2 = n2;
        }

        if (maxN1N2 > n3) {
            return maxN1N2;
        } else {
            return n3;
        }
    }

    public static int foo(int a, int b, int c) {
        if (a > 10) {
            if (c < 20) {
                for (int i = 0; i < b; i = i + 1) {
                    System.out.println("hello");
                }
                if (b < -5) {
                    System.out.println("bye");
                }
            } else {
                return a + b + c;
            }
        } else {
            if (a + b - c == 10) {
                System.out.println("hehe");
            } else if (a > b) {
                System.out.println("hoo");
            }
        }
        return 5;
    }

    public static int randomSum(int a, int b) {
        if (a == b) return 0;
        if (a > b) {
            return 1;
        } else if (a < b) {
            return -1;
        }
        return 2;
    }

    public static int getFare(int age, int distance) {
        int fare = 0;
        if (age > 4 && age < 14) {
            if (distance >= 10) {
                fare = 130;
            } else {
                fare = 100;
            }
        } else if (age > 15) {
            if (distance < 10 && age >= 60) {
                fare = 160;
            } else if (distance > 10 && age < 60) {
                fare = 250;
            } else {
                fare = 200;
            }
        }
        return fare;
    }

    public static int power(int i, int j) {
        int value;
        if (j < 0) {
            if (i == 1) {
                value = 1;
            } else if (i == 0) {
                return -1;
            } else {
                value = 0;
            }
        } else if (j == 0) {
            if (i >= 0) { // if (i == 0)
                return -1;
            } else {
                value = 1;
            }
        } else if (j >= 1) { // Error added here for the condition j == 1
            value = i;
        } else {
            value = 1;
            for (int k = 1; k <= j; k++) {
                value *= i;
            }
        }
        return value;
    }

    public static int gcd(int m, int n) {
        if (m < 0) m = -m;
        if (n < 0) n = -n;
        if (m == 0) return m; // return n
        if (n == 0) return n; // return m
        while (m != n) {
            if (m > n) m = m - n;
            else n = n - m;
        }
        return m;
    }

    public static int checkValidDate(int day, int month, int year) {
        if (day > 1 && month > 1 && year > 1 && day < 31 && month < 12 && year < 2024) {
            if ((month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) && (day <= 31))
                return 1;
            if ((month == 4 || month == 6 || month == 9 || month == 11) && (day <= 30)) return 1;
            if ((month == 2) && (day < 28)) return 1;
            if ((month == 2) && (day == 29) && (year % 4 == 0) && (year % 400 != 0)) return 1;
        }
        return 0;
    }

    public static boolean test(int a, int b) {
        if (a > 2 && b < 5 || a > 18) {
            return true;
        }
        return false;
    }

    public static int minimum(int a, int b, int c) {
        if (a < b && a < c) {
            return a;
        } else if (b < a && b < c) {
            return b;
        } else {
            return c;
        }
    }

    public static int methodInvocation(int x, int y) {
        if (minimum(x, y, 10) == y) {
            return 1;
        } else if (minimum(x, 3, 4) == x) {
            return 2;
        } else {
            return 3;
        }
    }

    public static int methodInvocationTwo(int x, int y) {
        if (Math.min(y, 10) == y) {
            return 1;
        } else if (minimum(x, 3, 4) == x) {
            return 2;
        } else {
            return 3;
        }
    }
//    public static int minimumY(int a, int b, int c) {
//        if (a < b) {
//            if (a < c) {
//                return a;
//            }
//        } else if (b < a) {
//            if (b < c) {
//                return b;
//            }
//        } else {
//            return c;
//        }
//    }

}
