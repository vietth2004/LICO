package largestDigit;

public class largestDigit {
    public int largestDigit(int n) {
        int max = 0;
        while (n > 0) {
            int d = n % 10;
            if (d > max) max = d;
            n /= 10;
        }
        return max;
    }
}
