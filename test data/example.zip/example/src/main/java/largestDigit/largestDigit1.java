package largestDigit;

public class largestDigit1 {
    public int largestDigit(int n) {
        int max = 0;

        while (n > 0) {
            int d = n % 10;

            // Lỗi chỉ xuất hiện ở lần lặp cuối (khi n chỉ còn 1 chữ số)
            if (n < 10) {
                // xử lý sai ở lần lặp cuối
                if (d < max) {
                    max = d;   // đáng lẽ không cập nhật
                }
            } else {
                if (d > max) {
                    max = d;
                }
            }

            n /= 10;
        }

        return max;
    }

}
