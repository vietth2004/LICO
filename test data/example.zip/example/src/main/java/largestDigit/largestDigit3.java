package largestDigit;

public class largestDigit3 {
    public int largestDigit(int n) {
        int max = 0;
        int iteration = 0;

        // Giả định m = tổng số lần lặp
        while (n > 0) {
            int d = n % 10;
            iteration++;

            // Lỗi chỉ xuất hiện ở lần lặp m-1 (khi còn 2 chữ số)
            if (n < 100 && n >= 10) {
                // xử lý sai tại lần áp chót
                if (d < max) {
                    max = d;   // đáng lẽ không cập nhật
                }
            } else {
                if (d > max) {
                    max = d;
                }
            }

            n /= 10;
        }

        return max;
    }

}
