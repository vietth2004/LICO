package largestDigit;

public class largestDigit4 {
    public int largestDigit(int n) {
        int max = 0;

        do {
            int d = n % 10;

            if (d > max) {
                max = d;
            }

            n /= 10;
        } while (n >= 0); // lỗi: điều kiện cho phép chạy thêm 1 lần

        return max;
    }

}
