package countDigits;

public class countDigits3 {
    public int countDigits(int num) {
    int count = 0, n = num;

    // LỖI: bỏ qua chữ số cuối cùng
    while (n >= 10) {
        int digit = n % 10;
        if (digit != 0 && num % digit == 0) count++;
        n /= 10;
    }

    return count;
}

}
