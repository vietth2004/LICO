package countDigits;

public class countDigits1 {
    public int countDigits(int num) {
    int count = 0, n = num;

    while (n > 0) {
        int digit = n % 10;

        // LỖI: bỏ qua chữ số đầu tiên
        if (n != num && digit != 0 && num % digit == 0)
            count++;

        n /= 10;
    }
    return count;
}

}
