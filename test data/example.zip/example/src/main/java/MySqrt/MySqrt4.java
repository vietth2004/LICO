package MySqrt;

public class MySqrt4 {
    public int mySqrt(int x) {
        long i = 0;

        // BUG: Điều kiện dừng bị nới lỏng (<= x + 1).
        // Với các số sát nút (như 3, 8...), nó có thể khiến i tăng thêm 1 lần thừa.
        while (i * i <= x + 1) {
            i++;
        }
        return (int) (i - 1);
    }
}