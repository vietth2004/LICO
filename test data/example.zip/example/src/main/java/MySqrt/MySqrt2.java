package MySqrt;

public class MySqrt2 {
    public int mySqrt(int x) {
        long i = 0;
        while (i * i <= x) {
            i++;
        }

        // BUG: Trả về i chưa trừ 1 -> Kết quả luôn lớn hơn 1 đơn vị so với đúng
        return (int) i;
    }
}