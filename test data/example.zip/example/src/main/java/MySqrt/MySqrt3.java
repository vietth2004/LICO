package MySqrt;

public class MySqrt3 {
    public int mySqrt(int x) {
        long i = 0;

        // BUG: Logic này thực ra là một cách viết đúng khác (tìm i trực tiếp),
        // nhưng nếu code gốc định trả về i-1 mà ở đây trả về i thì cần kiểm tra kỹ
        // input.
        // Ở đây giả lập lỗi logic so với thuật toán gốc.
        while ((i + 1) * (i + 1) <= x) {
            i++;
        }
        return (int) i;
    }
}