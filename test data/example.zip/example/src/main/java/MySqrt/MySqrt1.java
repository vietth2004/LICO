package MySqrt;

public class MySqrt1 {
    public int mySqrt(int x) {
        long i = 0;

        // BUG: Điều kiện lặp sai (< x) -> Nếu x là số chính phương (ví dụ 4, 9), vòng
        // lặp dừng quá sớm
        while (i * i < x) {
            i++;
        }
        return (int) (i - 1);
    }
}