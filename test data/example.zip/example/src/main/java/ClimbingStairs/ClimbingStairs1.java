package ClimbingStairs;

public class ClimbingStairs1 {
    public int climbStairs(int n) {
        if (n <= 2)
            return n;

        int a = 1, b = 2;

        // BUG: Điều kiện dừng sai (i < n thay vì i <= n) -> Chạy thiếu 1 bước
        for (int i = 3; i < n; i++) {
            int c = a + b;
            a = b;
            b = c;
        }

        return b;
    }
}