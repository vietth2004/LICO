package ClimbingStairs;

public class ClimbingStairs2 {
    public int climbStairs(int n) {
        if (n <= 2)
            return n;

        int a = 1, b = 2;

        // BUG: Điều kiện dừng sai (<= n - 1) -> Cũng chạy thiếu 1 bước
        for (int i = 3; i <= n - 1; i++) {
            int c = a + b;
            a = b;
            b = c;
        }

        return b;
    }
}