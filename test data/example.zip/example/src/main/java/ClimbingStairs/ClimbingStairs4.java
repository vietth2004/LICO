package ClimbingStairs;

public class ClimbingStairs4 {
    public int climbStairs(int n) {
        if (n <= 2)
            return n;

        // BUG: Khởi tạo sai (a = 0 thay vì a = 1) -> Sai cả dãy số sau đó
        int a = 0, b = 2;

        for (int i = 3; i <= n; i++) {
            int c = a + b;
            a = b;
            b = c;
        }

        return b;
    }
}