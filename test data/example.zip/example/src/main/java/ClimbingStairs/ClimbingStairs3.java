package ClimbingStairs;

public class ClimbingStairs3 {
    public int climbStairs(int n) {
        if (n <= 2)
            return n;

        int a = 1, b = 2;

        // BUG: Vòng lặp chạy thừa 1 lần (<= n + 1) -> Ra kết quả lớn hơn mong đợi
        for (int i = 3; i <= n + 1; i++) {
            int c = a + b;
            a = b;
            b = c;
        }

        return b;
    }
}