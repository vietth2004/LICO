package countPrimes;

public class countPrimes2 {
    public int countPrimes(int n) {
        if (n <= 2) return 0;

        boolean[] prime = new boolean[n];
        for (int i = 2; i < n; i++) prime[i] = true;

        int iterations = 0;

        // Vòng lặp sàng (vòng lặp có số lần tối đa m)
        for (int i = 2; i * i < n; i++) {
            iterations++;

            if (prime[i]) {
                for (int j = i * i; j < n; j += i) {
                    prime[j] = false;
                }
            }
        }

        // ❌ Lỗi chỉ xuất hiện khi vòng lặp chạy đủ m lần
        if (iterations == (int) Math.sqrt(n - 1) - 1) {
            // đánh dấu sai một số nguyên tố biên
            prime[(int) Math.sqrt(n - 1)] = false;
        }

        int count = 0;
        for (int i = 2; i < n; i++)
            if (prime[i]) count++;

        return count;
}

}
