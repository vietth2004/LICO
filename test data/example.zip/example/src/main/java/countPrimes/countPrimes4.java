package countPrimes;

public class countPrimes4 {
    public int countPrimes(int n) {
        if (n <= 2) return 0;

        boolean[] prime = new boolean[n];
        for (int i = 2; i < n; i++) prime[i] = true;

        int iterations = 0;

        // LỖI: điều kiện vòng lặp cho phép chạy dư 1 lần (m+1)
        for (int i = 2; i * i <= n; i++) {
            iterations++;

            if (prime[i]) {
                for (int j = i * i; j < n; j += i) {
                    prime[j] = false;
                }
            }
        }

        // Lỗi chỉ bộc lộ khi vòng lặp chạy m+1 lần
        if (iterations == (int) Math.sqrt(n - 1)) {
            // đánh dấu sai một số nguyên tố hợp lệ
            prime[(int) Math.sqrt(n - 1)] = false;
        }

        int count = 0;
        for (int i = 2; i < n; i++)
            if (prime[i]) count++;

        return count;
    }

}
