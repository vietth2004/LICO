package IsPrime;

public class IsPrime2 {
    public boolean isPrime(int n) {
        if (n <= 1)
            return false;

        // BUG: Khởi tạo mặc định là false.
        // Với n=2 hoặc n=3, vòng lặp không chạy -> Trả về false (SAI)
        boolean prime = false;

        for (int i = 2; i <= n / 2; i++) {
            if (n % i == 0)
                return false;
            prime = true;
        }
        return prime;
    }
}