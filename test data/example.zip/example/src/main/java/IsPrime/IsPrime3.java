package IsPrime;

public class IsPrime3 {
    public boolean isPrime(int n) {
        if (n <= 1)
            return false;

        // BUG: Điều kiện lặp thiếu dấu bằng (i < n / 2).
        // Với n=4, nó bỏ qua kiểm tra chia hết cho 2 -> Kết luận 4 là số nguyên tố
        // (SAI).
        for (int i = 2; i < n / 2; i++) {
            if (n % i == 0)
                return false;
        }

        return true;
    }
}