package IsPrime;

public class IsPrime1 {
    public boolean isPrime(int n) {
        if (n <= 1)
            return false;

        boolean hasDivisor = false;

        for (int i = 2; i <= n / 2; i++) {
            if (n % i == 0) {
                hasDivisor = true;
                // Đáng lẽ phải return false ngay hoặc break, nhưng code này chạy tiếp
            }
        }

        // BUG: Đảo ngược kết luận.
        // Hàm này trả về true nếu n là HỢP SỐ (có ước), false nếu n là số nguyên tố.
        return hasDivisor;
    }
}